﻿Windows 7, Visual Studio 2013, freeglut-MSVC-2.8.1-1에서 개발했습니다.
HW3\Debug 폴더의 HW3.exe를 실행하시면 됩니다.

Command 설명:
i, I : Bezier Curve로 만든 점들을 초기화합니다.
l, L : Bezier Curve로 만든 점들을 점선 또는 실선으로 그립니다.
a, A : AABB BVH를 그려줍니다.
o, O : OBB BVH를 그려줍니다.