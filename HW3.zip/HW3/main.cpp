#include <GL/glut.h>
#include "curve.h"
#include <vector>
#include <algorithm>
#include <iostream>

CubicBezierCurve curve;
GLsizei width = 640, height = 480;
int edit_ctrlpts_idx = -1;
bool isDrawControlMesh = true;
bool isDottedLine = false;
bool isAABB = true;
bool isOBB = false;
typedef std::vector<std::vector<float>> ConstantsDictType;
ConstantsDictType BeizerConstants;
typedef std::pair<float, float> PointType;
typedef std::vector<PointType> PointsType;
PointsType Points;
#define RES 1024

int hit_index(CubicBezierCurve *curve, int x, int y)
{
	for (int i = 0; i < 4; i++)
	{
		REAL tx = curve->control_pts[i][0] - x;
		REAL ty = curve->control_pts[i][1] - y;
		if ((tx * tx + ty * ty) < 30) return i;
	}
	return -1;
}

void init()
{
	SET_PT2(curve.control_pts[0], 50, 100);
	SET_PT2(curve.control_pts[1], 200, 300);
	SET_PT2(curve.control_pts[2], 400, 300);
	SET_PT2(curve.control_pts[3], 550, 100);
	BeizerConstants = std::vector<std::vector<float>>(1025);
	Points = std::vector<PointType>(1025);
	for (int i = 0; i <= RES; ++i)
	{
		float t = static_cast<float>(i) / RES;
		float one_minus_t = 1 - t;
		BeizerConstants[i] = std::vector<float>(4);
		BeizerConstants[i][0] = one_minus_t * one_minus_t * one_minus_t;
		BeizerConstants[i][1] = 3 * one_minus_t * one_minus_t * t;
		BeizerConstants[i][2] = 3 * one_minus_t * t * t;
		BeizerConstants[i][3] = t * t * t;
	}
	for (int i = 0; i <= RES; ++i)
	{
		Points[i] = PointType();
		for (int j = 0; j < 4; ++j)
		{
			Points[i].first += BeizerConstants[i][j] * curve.control_pts[j][0];
			Points[i].second += BeizerConstants[i][j] * curve.control_pts[j][1];
		}
	}
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, width, 0, height);
}

void reshape_callback(GLint nw, GLint nh)
{
	width = nw;
	height = nh;
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, width, 0, height);
}

void draw_AABB(const PointsType& points, unsigned int low, unsigned int high)
{
	if (points.size() <= 0)
	{
		return;
	}
	else if (points.size() <= low)
	{
		return;
	}
	else if (points.size() <= high)
	{
		return;
	}
	else if (high < low)
	{
		return;
	}

	float left = points[low].first;
	float right = points[low].first;
	float top = points[low].second;
	float bottom = points[low].second;
	for (unsigned int i = low + 1; i <= high; ++i)
	{
		if (points[i].first < left)
		{
			left = points[i].first;
		}
		if (right < points[i].first)
		{
			right = points[i].first;
		}
		if (top < points[i].second)
		{
			top = points[i].second;
		}
		if (points[i].second < bottom)
		{
			bottom = points[i].second;
		}
	}
	glBegin(GL_LINE_LOOP);
	glVertex2f(left, top);
	glVertex2f(left, bottom);
	glVertex2f(right, bottom);
	glVertex2f(right, top);
	glEnd();

	if (high - low <= 1)
	{
		return;
	}

	unsigned int average = low + ((high - low) / 2);
	draw_AABB(points, low, average);
	draw_AABB(points, average, high);
}

float InnerProduct(const PointType& lhs, const PointType& rhs)
{
	return lhs.first * rhs.first + lhs.second * rhs.second;
}

void draw_OBB(const PointsType& points, unsigned int low, unsigned int high)
{
	if (points.size() <= 0)
	{
		return;
	}
	else if (points.size() <= low)
	{
		return;
	}
	else if (points.size() <= high)
	{
		return;
	}
	else if (high < low)
	{
		return;
	}

	PointType vect = std::make_pair(points[high].first - points[low].first, points[high].second - points[low].second);
	PointType orthoVect = std::make_pair(vect.second, -vect.first);
	unsigned int leftIndex = low;
	unsigned int rightIndex = low;
	unsigned int topIndex = low;
	unsigned int bottomIndex = low;
	float left = InnerProduct(points[low], vect);
	float right = InnerProduct(points[low], vect);
	float top = InnerProduct(points[low], orthoVect);
	float bottom = InnerProduct(points[low], orthoVect);
	for (unsigned int i = low + 1; i <= high; ++i)
	{
		float vectValue = InnerProduct(points[i], vect);
		float orthoVectValue = InnerProduct(points[i], orthoVect);
		if (vectValue < left)
		{
			left = vectValue;
			leftIndex = i;
		}
		if (right < vectValue)
		{
			right = vectValue;
			rightIndex = i;
		}
		if (top < orthoVectValue)
		{
			top = orthoVectValue;
			topIndex = i;
		}
		if (orthoVectValue < bottom)
		{
			bottom = orthoVectValue;
			bottomIndex = i;
		}
	}
	float x1 = (orthoVect.second * vect.first * points[leftIndex].first + orthoVect.second * vect.second * points[leftIndex].second - vect.second * orthoVect.first * points[topIndex].first - vect.second * orthoVect.second * points[topIndex].second) / (orthoVect.second * vect.first - vect.second * orthoVect.first);
	float y1 = (orthoVect.first * vect.first * points[leftIndex].first + orthoVect.first * vect.second * points[leftIndex].second - vect.first * orthoVect.first * points[topIndex].first - vect.first * orthoVect.second * points[topIndex].second) / (orthoVect.first * vect.second - vect.first * orthoVect.second);
	float x2 = (orthoVect.second * vect.first * points[leftIndex].first + orthoVect.second * vect.second * points[leftIndex].second - vect.second * orthoVect.first * points[bottomIndex].first - vect.second * orthoVect.second * points[bottomIndex].second) / (orthoVect.second * vect.first - vect.second * orthoVect.first);
	float y2 = (orthoVect.first * vect.first * points[leftIndex].first + orthoVect.first * vect.second * points[leftIndex].second - vect.first * orthoVect.first * points[bottomIndex].first - vect.first * orthoVect.second * points[bottomIndex].second) / (orthoVect.first * vect.second - vect.first * orthoVect.second);
	float x3 = (orthoVect.second * vect.first * points[rightIndex].first + orthoVect.second * vect.second * points[rightIndex].second - vect.second * orthoVect.first * points[bottomIndex].first - vect.second * orthoVect.second * points[bottomIndex].second) / (orthoVect.second * vect.first - vect.second * orthoVect.first);
	float y3 = (orthoVect.first * vect.first * points[rightIndex].first + orthoVect.first * vect.second * points[rightIndex].second - vect.first * orthoVect.first * points[bottomIndex].first - vect.first * orthoVect.second * points[bottomIndex].second) / (orthoVect.first * vect.second - vect.first * orthoVect.second);
	float x4 = (orthoVect.second * vect.first * points[rightIndex].first + orthoVect.second * vect.second * points[rightIndex].second - vect.second * orthoVect.first * points[topIndex].first - vect.second * orthoVect.second * points[topIndex].second) / (orthoVect.second * vect.first - vect.second * orthoVect.first);
	float y4 = (orthoVect.first * vect.first * points[rightIndex].first + orthoVect.first * vect.second * points[rightIndex].second - vect.first * orthoVect.first * points[topIndex].first - vect.first * orthoVect.second * points[topIndex].second) / (orthoVect.first * vect.second - vect.first * orthoVect.second);
	glBegin(GL_LINE_LOOP);
	glVertex2f(x1, y1);
	glVertex2f(x2, y2);
	glVertex2f(x3, y3);
	glVertex2f(x4, y4);
	glEnd();

	if (high - low <= 1)
	{
		return;
	}

	unsigned int average = low + ((high - low) / 2);
	draw_OBB(points, low, average);
	draw_OBB(points, average, high);
}

void display_callback()
{
	/* curve */
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3ub(0, 0, 0);
	if (isDottedLine)
		glBegin(GL_LINES);
	else
		glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= RES; i++)
	{
		glVertex2f(Points[i].first, Points[i].second);
	}
	glEnd();

	// draw AABB
	if (isAABB)
	{
		glColor3ub(0, 255, 0);
		draw_AABB(Points, 0, RES);
	}

	// draw OBB
	if (isOBB)
	{
		glColor3ub(0, 255, 0);
		draw_OBB(Points, 0, RES);
	}

	/* control mesh */
	if (isDrawControlMesh)
	{
		glColor3ub(255, 0, 0);
		glBegin(GL_LINE_STRIP);
		for (int i = 0; i < 4; i++)
		{
			REAL *pt = curve.control_pts[i];
			glVertex2f(pt[0], pt[1]);
		}
		glEnd();
	}

	/* control pts */
	glColor3ub(0, 0, 255);
	glPointSize(10.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < 4; i++)
	{
		REAL *pt = curve.control_pts[i];
		glVertex2f(pt[0], pt[1]);
	}
	glEnd();
	glutSwapBuffers();
}

// void glutMouseFunc(void (*func)(int button, int state, int x, int y));
void mouse_callback(GLint button, GLint action, GLint x, GLint y)
{
	if (GLUT_LEFT_BUTTON == button)
	{
		switch (action)
		{
		case GLUT_DOWN:
			edit_ctrlpts_idx = hit_index(&curve, x, height - y);
			break;
		case GLUT_UP:
			edit_ctrlpts_idx = -1;
			break;
		default: break;
		}
	}
	glutPostRedisplay();
}

// void glutMotionFunc(void (*func)(int x, int y));
void mouse_move_callback(GLint x, GLint y)
{
	if (edit_ctrlpts_idx != -1)
	{
		curve.control_pts[edit_ctrlpts_idx][0] = static_cast<float>(x);
		curve.control_pts[edit_ctrlpts_idx][1] = static_cast<float>(height - y);
		for (int i = 0; i <= RES; ++i)
		{
			Points[i] = PointType();
			for (int j = 0; j < 4; ++j)
			{
				Points[i].first += BeizerConstants[i][j] * curve.control_pts[j][0];
				Points[i].second += BeizerConstants[i][j] * curve.control_pts[j][1];
			}
		}
	}
	glutPostRedisplay();
}

// void glutKeyboardFunc(void (*func)(unsigned char key, int x, int y));
void keyboard_callback(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'i': case 'I':
		SET_PT2(curve.control_pts[0], 50, 100);
		SET_PT2(curve.control_pts[1], 200, 300);
		SET_PT2(curve.control_pts[2], 400, 300);
		SET_PT2(curve.control_pts[3], 550, 100);
		for (int i = 0; i <= RES; ++i)
		{
			Points[i] = PointType();
			for (int j = 0; j < 4; ++j)
			{
				Points[i].first += BeizerConstants[i][j] * curve.control_pts[j][0];
				Points[i].second += BeizerConstants[i][j] * curve.control_pts[j][1];
			}
		}
		break;
	case 'l': case 'L':
		isDottedLine ^= true;
		break;
	case 'c': case 'C':
		isDrawControlMesh ^= true;
		break;
	case 'a':
	case 'A':
		isAABB ^= true;
		break;
	case 'o':
	case 'O':
		isOBB ^= true;
		break;
	case (27) : exit(0); break;
	default: break;
	}
	glutPostRedisplay();
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(width, height);
	glutCreateWindow("Beizer Editor");

	init();
	glutReshapeFunc(reshape_callback);
	glutMouseFunc(mouse_callback);
	glutMotionFunc(mouse_move_callback);
	glutDisplayFunc(display_callback);
	glutKeyboardFunc(keyboard_callback);
	glutMainLoop();

	return 0;
}
