﻿Windows 7, Visual Studio 2013, freeglut-MSVC-2.8.1-1에서 개발했습니다.
HW4\Debug 또는 HW4\Release 폴더의 HW4.exe를 실행하시면 됩니다.

단 control points 옮기는 작업을 할 때 버그가 있으며, Radius 수정하는 작업은 하지 않았습니다.