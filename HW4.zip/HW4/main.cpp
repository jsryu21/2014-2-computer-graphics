#include <GL/glut.h>
#include "curve.h"
#include <vector>
#include <list>
#include <algorithm>
#include <iostream>
#include <limits>
#include <array>
#define _USE_MATH_DEFINES
#include <math.h>
#include "Matrices.h"

const static int ROUND_DIV_COUNT = 32;
const static int RES = 1024;
const static int RADIUS = 50;
CubicBezierCurve curve;
GLsizei width = 640, height = 800;
int edit_ctrlpts_idx = -1;
bool isDrawControlMesh = true;
typedef std::vector<std::array<float, 4>> ConstantsDictType;
ConstantsDictType BeizerConstants;
typedef std::vector<std::array<Vector3, ROUND_DIV_COUNT>> CirclePointsType;
typedef std::vector<Vector3> CenterPointsType;
CirclePointsType Points;
CenterPointsType CenterPoints;

double Radians(double degrees)
{
	return degrees * M_PI / 180;
}
double Degrees(double radians)
{
	return radians * 180 / M_PI;
}

int hit_index(CubicBezierCurve* curve, int x, int y)
{
	for (int i = 0; i < 4; i++)
	{
		REAL tx = curve->control_pts[i][0] - x * 2;
		REAL ty = curve->control_pts[i][1] - y;
		if ((tx * tx + ty * ty) < 30) return i;
	}
	return -1;
}

/**
* get a point-normal
*/
Vector3 GetNormal(float x, float y, float z)
{
	float a = -static_cast<float>(M_PI) / 2;
	float ca = cosf(a);
	float sa = sinf(a);
	float nx = x*ca - y*sa;
	float ny = x*sa + y*ca;
	float dst = sqrt(nx*nx + ny*ny);
	return Vector3(nx / dst, ny / dst, z);
}

void AssignPoints()
{
	for (int i = 0; i <= RES; ++i)
	{
		Vector3& center = CenterPoints[i];
		center.set(0, 0, 0);
		for (int j = 0; j < 4; ++j)
		{
			center[0] += BeizerConstants[i][j] * curve.control_pts[j][0];
			center[1] += BeizerConstants[i][j] * curve.control_pts[j][1];
		}
		auto& circle = Points[i];
		circle.fill(center);
		auto& temp = GetNormal(center.x, center.y, center.z).normalize();
		for (int j = 0; j < ROUND_DIV_COUNT; ++j)
		{
			circle[j].x += temp.x * RADIUS * cosf(2 * static_cast<float>(M_PI) * j / ROUND_DIV_COUNT);
			circle[j].y += temp.y * RADIUS * cosf(2 * static_cast<float>(M_PI)* j / ROUND_DIV_COUNT);
			circle[j].z += RADIUS * sinf(2 * static_cast<float>(M_PI)* j / ROUND_DIV_COUNT);
		}
	}
}

void InitControlPoints()
{
	SET_PT3(curve.control_pts[0], 50, 100, 0);
	SET_PT3(curve.control_pts[1], 200, 300, 0);
	SET_PT3(curve.control_pts[2], 400, 300, 0);
	SET_PT3(curve.control_pts[3], 550, 100, 0);
}

void init()
{
	InitControlPoints();
	BeizerConstants = ConstantsDictType(RES + 1);
	Points = CirclePointsType(RES + 1);
	CenterPoints = CenterPointsType(RES + 1);
	for (int i = 0; i <= RES; ++i)
	{
		float t = static_cast<float>(i) / RES;
		float one_minus_t = 1 - t;
		BeizerConstants[i][0] = one_minus_t * one_minus_t * one_minus_t;
		BeizerConstants[i][1] = 3 * one_minus_t * one_minus_t * t;
		BeizerConstants[i][2] = 3 * one_minus_t * t * t;
		BeizerConstants[i][3] = t * t * t;
	}
	AssignPoints();
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, width, 0, height);
}

void reshape_callback(GLint nw, GLint nh)
{
	width = nw;
	height = nh;
	glViewport(0, 0, width / 2, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, width, 0, height);
	glViewport(width / 2, 0, width / 2, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1000, 1000);
}

void display_callback()
{
	glClearColor(1.f, 1.f, 1.f, 1.f);
	glClear(GL_COLOR_BUFFER_BIT);
	glViewport(0, 0, width / 2, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, width, 0, height);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	/* curve */
	glColor3ub(0, 0, 0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= RES; i++)
	{
		glVertex3f(CenterPoints[i].x, CenterPoints[i].y, CenterPoints[i].z);
	}
	glEnd();

	/* control mesh */
	if (isDrawControlMesh)
	{
		glColor3ub(255, 0, 0);
		glBegin(GL_LINE_STRIP);
		for (int i = 0; i < 4; i++)
		{
			REAL *pt = curve.control_pts[i];
			glVertex3f(pt[0], pt[1], pt[2]);
		}
		glEnd();
	}

	/* control pts */
	glColor3ub(0, 0, 255);
	glPointSize(10.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < 4; i++)
	{
		REAL *pt = curve.control_pts[i];
		glVertex3f(pt[0], pt[1], pt[2]);
	}
	glEnd();
	glViewport(width / 2, 0, width / 2, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-width, width, -height, height, -1000, 1000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	Vector3 up = GetNormal(-1, -1, -1);
	gluLookAt(1, 1, 1, 0, 0, 0, up.x, up.y, up.z);
	/* curve */
	glColor3ub(0, 0, 0);
	for (int i = 0; i < RES; i++)
	{
		glBegin(GL_QUAD_STRIP);
		for (int j = 0; j < ROUND_DIV_COUNT; ++j)
		{
			glVertex3f(Points[i][j][0], Points[i][j][1], Points[i][j][2]);
			glVertex3f(Points[i + 1][j][0], Points[i + 1][j][1], Points[i + 1][j][2]);
		}
		int j = 0;
		glVertex3f(Points[i][j][0], Points[i][j][1], Points[i][j][2]);
		glVertex3f(Points[i + 1][j][0], Points[i + 1][j][1], Points[i + 1][j][2]);
		glEnd();
	};

	/* control mesh */
	if (isDrawControlMesh)
	{
		glColor3ub(255, 0, 0);
		glBegin(GL_LINE_STRIP);
		for (int i = 0; i < 4; i++)
		{
			REAL *pt = curve.control_pts[i];
			glVertex3f(pt[0], pt[1], pt[2]);
		}
		glEnd();
	}

	/* control pts */
	glColor3ub(0, 0, 255);
	glPointSize(10.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < 4; i++)
	{
		REAL *pt = curve.control_pts[i];
		glVertex3f(pt[0], pt[1], pt[2]);
	}
	glEnd();
	glutSwapBuffers();
}

// void glutMouseFunc(void (*func)(int button, int state, int x, int y));
void mouse_callback(GLint button, GLint action, GLint x, GLint y)
{
	if (GLUT_LEFT_BUTTON == button)
	{
		switch (action)
		{
		case GLUT_DOWN:
			edit_ctrlpts_idx = hit_index(&curve, x, height - y);
			break;
		case GLUT_UP:
			edit_ctrlpts_idx = -1;
			break;
		default: break;
		}
	}
	glutPostRedisplay();
}

// void glutMotionFunc(void (*func)(int x, int y));
void mouse_move_callback(GLint x, GLint y)
{
	if (edit_ctrlpts_idx != -1)
	{
		curve.control_pts[edit_ctrlpts_idx][0] = static_cast<float>(x);
		curve.control_pts[edit_ctrlpts_idx][1] = static_cast<float>(height - y);
		AssignPoints();
	}
	glutPostRedisplay();
}

// void glutKeyboardFunc(void (*func)(unsigned char key, int x, int y));
void keyboard_callback(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'i': case 'I':
		InitControlPoints();
		AssignPoints();
		break;
	case 'c': case 'C':
		isDrawControlMesh ^= true;
		break;
	case (27) : exit(0); break;
	default: break;
	}
	glutPostRedisplay();
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(width, height);
	glutCreateWindow("Beizer Editor");

	init();
	glutReshapeFunc(reshape_callback);
	glutMouseFunc(mouse_callback);
	glutMotionFunc(mouse_move_callback);
	glutDisplayFunc(display_callback);
	glutKeyboardFunc(keyboard_callback);
	glutMainLoop();

	return 0;
}
