﻿Windows 7, Visual Studio 2013, freeglut-MSVC-2.8.1-1에서 개발했습니다.
그런데 remote desktop에서 텍스쳐가 잘 표시되지 않습니다.
HW4\Debug 또는 HW4\Release 폴더의 HW4.exe를 실행하시면 됩니다.

마우스 휠로 Radius 조정하는 기능이 잘 동작하지 않아서(mouse callback function이 불리지 않는 경우가 있습니다.)
Control Point들 위에 마우스를 올리고 b 를 누르면 Radius가 커지고, s 를 누르면 Radius가 작아집니다.

Dampling 기능을 하기 위해서는 d 를 누른뒤에 control point를 움직이면 됩니다.