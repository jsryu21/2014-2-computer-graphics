﻿Windows 7, Visual Studio 2013, freeglut-MSVC-2.8.1-1에서 개발했습니다.
각 숙제의 Debug 폴더의 HW2_*.exe를 실행하시면 됩니다.
HW2_1\Debug\HW2_1.exe
HW2_2\Debug\HW2_2.exe
HW2_3\Debug\HW2_3.exe
HW2_4\Debug\HW2_4.exe