﻿Windows 7, Visual Studio 2013, freeglut-MSVC-2.8.1-1에서 개발했습니다.
그런데 remote desktop에서 텍스쳐가 잘 표시되지 않아 일반 PC에서 개발했는데 Visual Studio 2012로 프로젝트 설정을 바꾸어 실행했습니다.
HW4\Debug 또는 HW4\Release 폴더의 HW4.exe를 실행하시면 됩니다.

Radius 조정하는 기능이 break point를 잡아놓고 실행하면 잘 되는데 그렇지 않으면 안되는 경우가 있습니다.